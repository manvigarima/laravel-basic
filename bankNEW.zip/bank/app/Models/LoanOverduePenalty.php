<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class LoanOverduePenalty extends Model
{
    protected $table = "loan_overdue_penalties";

    public $timestamps = false;


}
