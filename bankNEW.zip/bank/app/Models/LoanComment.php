<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class LoanComment extends Model
{
    protected $table = "loan_comments";

}
