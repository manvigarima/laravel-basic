<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SavingCharge extends Model
{
    protected $table = "savings_charges";

}
