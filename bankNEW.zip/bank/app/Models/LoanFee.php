<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class LoanFee extends Model
{
    protected $table = "loan_fees";

    public $timestamps = false;
}
